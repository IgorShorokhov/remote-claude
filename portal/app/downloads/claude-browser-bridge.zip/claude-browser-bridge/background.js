import { getConfig, setConfig, getSession } from "./lib/store.js";
import * as bridge from "./lib/bridge.js";
import { hooks, forgetTab, grant, GROUP_TITLE } from "./lib/commands.js";
import { releaseStale, releaseAll } from "./lib/cdp.js";

async function paintBadge() {
  const cfg = await getConfig();
  const requests = await getSession("requests", []);
  let text = "", color = "#6b7280", title = "Claude Browser Bridge";
  if (!cfg.token) { title += ": not signed in"; }
  else if (requests.length) { text = "?"; color = "#d97757"; title += ": Claude asks for access to a tab"; }
  else if (!cfg.enabled) { text = "II"; color = "#6b7280"; title += ": paused"; }
  else if (bridge.link.state === "connected") { text = "ON"; color = "#16a34a"; title += ": connected"; }
  else if (bridge.link.state === "connecting") { text = "…"; color = "#ca8a04"; title += ": connecting"; }
  else { text = "!"; color = "#dc2626"; title += ": " + (bridge.link.error || "offline"); }
  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color });
  await chrome.action.setTitle({ title });
}

bridge.onChange(() => { paintBadge(); chrome.runtime.sendMessage({ type: "changed" }).catch(() => {}); });
hooks.requestsChanged = () => { paintBadge(); chrome.runtime.sendMessage({ type: "changed" }).catch(() => {}); };

async function start() {
  await releaseStale();
  const cfg = await getConfig();
  if (cfg.token) bridge.connect();
  else if (await getSession("signin", null)) bridge.pollSignIn();
  paintBadge();
}

chrome.runtime.onInstalled.addListener(start);
chrome.runtime.onStartup.addListener(start);
chrome.alarms.create("keepalive", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "keepalive") return;
  const cfg = await getConfig();
  if (cfg.token && bridge.link.state !== "connected") bridge.connect();
  if (await getSession("signin", null)) bridge.pollSignIn();
});
chrome.tabs.onRemoved.addListener((tabId) => { forgetTab(tabId); });
chrome.debugger.onDetach.addListener((source, reason) => {
  if (reason === "canceled_by_user") {
    // The owner pressed "Cancel" on Chrome's debugging bar: that means stop.
    setConfig({ enabled: false }).then(() => { paintBadge(); bridge.reportState(); chrome.runtime.sendMessage({ type: "changed" }).catch(() => {}); });
  }
});

const handlers = {
  async status() { return bridge.summary(); },
  async "signin.start"(m) { return bridge.startSignIn(m.portal, m.label); },
  async "signin.cancel"() { await bridge.cancelSignIn(); return {}; },
  async signout() { await bridge.signOut(false); await paintBadge(); return {}; },
  async reconnect() { bridge.disconnect(); await bridge.connect(); return {}; },
  async "config.set"(m) {
    const allowed = {};
    if (typeof m.enabled === "boolean") allowed.enabled = m.enabled;
    if (m.scope === "group" || m.scope === "all") allowed.scope = m.scope;
    if (typeof m.allowEval === "boolean") allowed.allowEval = m.allowEval;
    if (Array.isArray(m.blocked)) allowed.blocked = m.blocked.map((x) => String(x).trim()).filter(Boolean).slice(0, 100);
    await setConfig(allowed);
    if (allowed.enabled === false) await releaseAll();
    await paintBadge();
    bridge.reportState();
    return {};
  },
  async "tab.allow"(m) { await grant(m.tabId); return {}; },
  async "tab.deny"(m) {
    const requests = (await getSession("requests", [])).filter((r) => r.tabId !== m.tabId);
    await chrome.storage.session.set({ requests });
    hooks.requestsChanged();
    return {};
  },
  async "tab.allowCurrent"() {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab) throw new Error("No active tab.");
    await grant(tab.id);
    return { tabId: tab.id, title: tab.title };
  },
};

chrome.runtime.onMessage.addListener((m, sender, respond) => {
  if (sender.id !== chrome.runtime.id || !m || !Object.hasOwn(handlers, m.type)) return false;
  handlers[m.type](m).then((r) => respond({ ok: true, ...r }), (e) => respond({ ok: false, error: String(e && e.message || e) }));
  return true;
});

globalThis.__bridge = { handlers, bridge, GROUP_TITLE };
start();
