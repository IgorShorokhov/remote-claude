const $ = (id) => document.getElementById(id);
let current = null;

function send(message) {
  return chrome.runtime.sendMessage(message).then((r) => {
    if (r && r.ok === false) throw new Error(r.error);
    return r;
  });
}

function show(id, on) { $(id).hidden = !on; }

function setError(text) {
  $("error").textContent = text || "";
  show("error", !!text);
}

function render(s) {
  current = s;
  const waiting = !!s.signin;
  show("signed-out", !s.signedIn && !waiting);
  show("waiting", !s.signedIn && waiting);
  show("signed-in", s.signedIn);
  const pill = $("pill");
  let label = "Not signed in", cls = "off";
  if (s.signedIn) {
    if (!s.enabled) { label = "Paused"; cls = "off"; }
    else if (s.link === "connected") { label = "Connected"; cls = "on"; }
    else if (s.link === "connecting") { label = "Connecting…"; cls = "warn"; }
    else { label = "Offline"; cls = "bad"; }
  } else if (waiting) { label = "Waiting for approval"; cls = "warn"; }
  pill.textContent = label;
  pill.className = "pill " + cls;
  setError(s.error);

  if (!s.signedIn && !waiting) {
    if (document.activeElement !== $("portal")) $("portal").value = s.portal;
  }
  if (waiting) $("code").textContent = s.signin.user_code;
  if (!s.signedIn) return;

  $("who").textContent = (s.email || "signed in") + (s.label ? " · " + s.label : "");
  $("enabled").checked = s.enabled;
  $("enabled-note").textContent = s.enabled ? "Claude can work in the tabs allowed below." : "Claude is paused and cannot do anything.";
  $("scope").value = s.scope;
  $("eval").checked = s.allowEval;
  if (document.activeElement !== $("blocked")) $("blocked").value = (s.blocked || []).join("\n");

  const list = $("request-list");
  list.textContent = "";
  for (const r of s.requests) {
    const li = document.createElement("li");
    const name = document.createElement("span");
    name.className = "name";
    name.textContent = (r.title || r.url || "Tab") + (r.url ? " · " + r.url : "");
    const yes = document.createElement("button");
    yes.textContent = "Allow";
    yes.onclick = () => send({ type: "tab.allow", tabId: r.tabId }).then(refresh, (e) => setError(e.message));
    const no = document.createElement("button");
    no.textContent = "Deny";
    no.onclick = () => send({ type: "tab.deny", tabId: r.tabId }).then(refresh, (e) => setError(e.message));
    li.append(name, yes, no);
    list.append(li);
  }
  show("requests", s.requests.length > 0);

  const log = $("log");
  log.textContent = "";
  for (const e of s.log) {
    const li = document.createElement("li");
    const t = document.createElement("span");
    t.className = "t";
    t.textContent = new Date(e.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const d = document.createElement("span");
    d.className = e.ok ? "" : "bad";
    d.textContent = e.tool + (e.detail ? " · " + e.detail : "") + (e.ok ? "" : " · " + (e.error || "failed"));
    li.append(t, d);
    log.append(li);
  }
  show("log-empty", s.log.length === 0);
}

async function refresh() {
  try { render(await send({ type: "status" })); } catch (e) { setError(e.message); }
}

$("connect").onclick = async () => {
  setError("");
  try { await send({ type: "signin.start", portal: $("portal").value, label: $("label").value }); } catch (e) { setError(e.message); }
  refresh();
};
$("cancel").onclick = () => send({ type: "signin.cancel" }).then(refresh);
$("signout").onclick = () => send({ type: "signout" }).then(refresh);
$("reconnect").onclick = () => send({ type: "reconnect" }).then(refresh);
$("enabled").onchange = (e) => send({ type: "config.set", enabled: e.target.checked }).then(refresh);
$("scope").onchange = (e) => send({ type: "config.set", scope: e.target.value }).then(refresh);
$("eval").onchange = (e) => send({ type: "config.set", allowEval: e.target.checked }).then(refresh);
$("save-blocked").onclick = () => send({ type: "config.set", blocked: $("blocked").value.split("\n") }).then(refresh, (e) => setError(e.message));
$("allow-current").onclick = async () => {
  try {
    const r = await send({ type: "tab.allowCurrent" });
    setError("");
    $("allow-current").textContent = "Allowed: " + (r.title || "this tab").slice(0, 28);
    setTimeout(() => { $("allow-current").textContent = "Let Claude use this tab"; }, 2500);
  } catch (e) { setError(e.message); }
  refresh();
};

chrome.runtime.onMessage.addListener((m) => { if (m && m.type === "changed") refresh(); });
refresh();
